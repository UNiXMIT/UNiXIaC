# PFSSO - Get AWS Credentials via Micro Focus Federation (NetIQ)

**You must now enable 2-factor authentication to access Micro Focus AWS accounts.  See the "Using 2-Factor Authentication" section below.  Or, try adding "--tokenmode ask" to your pfsso command line.**

[TOC]

## About

pfsso is a command-line interface to use your MFI Corporate credentials to get temporary (STS) credentials for AWS access.  It uses the Corporate federation services (NetIQ Access Manager) to generate a SAML assertion that can be traded with the AWS Security Token Service for temporary access and secret keys.  These keys can be used for command line tools such as Terraform, the AWS CLI, and other tools.



## Prerequisites

pfsso has been successfully installed and used on the following operating systems:

- Windows (7, 10)
- MacOS
- Linux (Centos 7/8, RHEL 7/8, Ubuntu 16.04/18.04/20.04, Amazon Linux 2)

pfsso is a Python program, and as such needs a working Python installation on your computer.  To install Python 3 on your computer:

- Windows/Mac: https://www.python.org/downloads
- Debian/Ubuntu: apt install python3 python3-pip
- RHEL/CentOS: yum install python3

pfsso has been tested with Python2 releases 2.7.16 and above, and Python3 releases of 3.6 through 3.9.  It may work with other versions, but they have not been tested.  Python2 is end-of-life, and not recommended for current installations.



## Getting the Software

The software is hosted on the Micro Focus GitHub Enterprise (GHE) service.  The URL for the software is:

    https://github.houston.softwaregrp.net/HPE-SW-SaaS/pfsso-python

Corporate credentials are needed to access the repositories on GHE.

Once logged in to GHE, download the latest release of pfsso (this is packaged as a zip file).



## Installing

    Note: Depending on your OS and Python installations, your Python 3 executable may be called 'python' or 'python3'.

1. Get a shell (command prompt);
2. Unzip your downloaded pfsso zipfile;
3. Change directory into your new unzipped folder.  If you see a file named "setup.py", you're in the correct folder.
4. Install.  Use the second version of the command below only if the first doesn't work for you;
   - python3 -m pip install .
   - python3 ./setup.py install



## Upgrading

    Note: Depending on your OS and Python installations, your Python 3 executable may be called 'python' or 'python3'.

1. Get a shell (command prompt);
2. Unzip your downloaded pfsso zipfile;
3. Change directory into your new unzipped folder.   If you see a file named "setup.py", you're in the correct folder;
4. Install.  Use the second version of the command below only if the first doesn't work for you;
   - python3 -m pip install --upgrade .
   - python3 ./setup.py install



## Proxy Support

Since pfsso is a Web application, depending on your network connection to Corporate, you may need HTTP proxies configured to make Web requests to the Corporate authentication server, or to the Internet (to send API calls to AWS).

Since connectivity can be different between Micro Focus locations, you may need to experiment with proxy settings.  Unless you know for sure, it's suggested you try running pfsso without proxy settings first, then add the proxy settings to see if that solves your issue.

    export http_proxy=http://proxy.houston.softwaregrp.net:8080
    export https_proxy=http://proxy.houston.softwaregrp.net:8080



## Quick Start

Show the version of pfsso installed:

    pfsso --version

Get credentials of all accounts to which I have access:

    pfsso -a

Get credentials only for the AWS accounts  763426134325 and 264163282450:

    pfsso -r 763426134325 264163282450

Get credentials for an AWS account, with a 8-hour session, and SMS 2-factor authentication:

    pfsso -s 8 --tokenmode "SMS OTP" -r 763426134325



## Output

This tool will write credentials to ``~/.aws/credentials`` as separate profiles based upon the AWS 
account ID number and your AWS account ID number plus role name. When you run the tool, it will 
tell you what AWS profile names it has written to your credentials file.

To use the credentials, use something like the following:

**AWS CLI:**

    aws --profile <ACCT_ID OR PROFILE_NAME>

**Python/boto3:**

    session = boto3.Session(profile_name=<ACCT_ID>)
    return session.client('ec2')

For other languages, look for whatever implementation they provide for accessing AWS credential 
profiles.



## Arguments

    usage: pfsso [-h] [-a] [-r ACCOUNTS [ACCOUNTS ...]] [-c CREDS_FILE]
                 [-n CONFIG] [-o OUTPUT] [-s {1,2,3,4,5,6,7,8,9,10,11,12}]
                 [-2 TOKENMODE] [-m MGMT_ACCT_ID] [-l] [-u USERNAME] [-g REGION]
                 [-v] [-t] [--version]
    
    optional arguments:
      -h, --help            show this help message and exit
      -a, --all-roles       Refresh credentials for all roles
      -r ACCOUNTS [ACCOUNTS ...], --accounts ACCOUNTS [ACCOUNTS ...]
                            List of AWS Account IDs to refresh
      -c CREDS_FILE, --creds-file CREDS_FILE
                            AWS Credentials file (default ~/.aws/credentials)
      -n CONFIG, --config CONFIG
                            Set profile aliases (default ~/.aws/pfsso_config)
      -o OUTPUT, --output OUTPUT
                            AWS output format (default json)
      -s {1,2,3,4,5,6,7,8,9,10,11,12}, --hours {1,2,3,4,5,6,7,8,9,10,11,12}
                            Session duration (hours)
      -2 TOKENMODE, --tokenmode TOKENMODE
                            Authenticator for 2-factor. Use 'ask' for choices.
      -m MGMT_ACCT_ID, --mgmt-acct-id MGMT_ACCT_ID
                            Management Account ID
      -l, --roles           Display AWS roles only
      -u USERNAME, --username USERNAME
                            SSO Username
      -g REGION, --region REGION
                            AWS Region (default ENV ${AWS_REGION}
      -v, --verbose         Print verbose debugging messages
      -t, --trace           Print more verbose debugging messages
      --version             Print version and exit



## Using 2-Factor Authentication

pfsso supports NetIQ Advanced Authentication protocols, which adds a user-configurable third value to the already-required username/password factor.  To enable use of 2-factor, include the **--tokenmode** argument when calling pfsso:

pfsso -s --tokenmode ask

The values of the tokenmode argument depend on how you've set up your "enrolled authenticators."  The typical values for this are one from the following list (which depends on whether you've set it up, and if you're using the smartphone app):

|                |                                                              |
| -------------- | ------------------------------------------------------------ |
| SMS OTP        | Sends an SMS code to your registered phone number, waits for you to enter it. |
| SmartPhonePush | Requires the iOS/Android app.  Pops an accept/deny choice on your phone, waits for you to choose. |
| TOTP           | Requires the iOS/Android app.  Waits for you to enter the current one-time-password code as displayed in the app. |
| HOTP           | Requires a hardware token generator.  Waits for you to enter
the current one-time-password code as displayed in the device. |

The special mode "ask" queries the access manager for your enrolled authenticators and prints a simple menu.  Choose the number of your desired authenticator mode to proceed.

```
$ pfsso --tokenmode ask -a
SSO Password:
doing 2fa sequence ask
Getting MFA token choices
Available MFA Authenticators
1. SMS OTP
2. SmartPhonePush
3. TOTP
4. HOTP
Select authenticator number:
```

You can set an environment variable named PFSSO_TOKENMODE to the name of your favorite authenticator, and it'll be used automatically (unless overridden by a command line --tokenmode parameter).

    export PFSSO_TOKENMODE="SMS OTP"



## Profile Aliases

If you wish to setup profile aliases for certain account/role combinations, copy the 
``pfsso_config.sample`` file to ``~/.aws/pfsso_config``, and replace the <> variables with:

* AWS account ID number
* AWS role that you have access to
* Profile alias name

Create a new section for each alias you want to have.



## Using the Python Module Interface

If you wish to use any of these functions in your own code, install via pip and use as follows:

    from pfsso.pfsso import pfsso
    pfsso.some_function()




## Contact

If you have questions, please fill out an issue on the Micro Focus GitHub and contact the CCoE Team (PSDC CCoE <swpdl.gsts.tse.ccoe@microfocus.com>).



## Fun Facts

The name "pfsso" originated as an acronym for "PingFederate Single Sign-On,"  back when we used PingFederate as our SSO solution.



## Appendix A: Workarounds for Known OS Bugs/Quirks

The following sections detail known issues and, as possible, workarounds to get pfsso running on certain OS releases.

### Ubuntu 20.04 (LTS), Windows

**ISSUE**: After installing pfsso successfully, you try to run it and it prints a long stacktrace, ending with:

**WORKAROUND**: This is a TLS protocol mismatch between the OpenSSL version packaged with 20.04, and with current protocol versions supported currently with NetIQ.  You can fix this by either:

- Manually upgrade openssl on the system to 1.1.1g (which is not released by Canonical at this time, they’re still pushing 1.1.1f);
- Allow OpenSSL to use TLS 1.2 and SHA1. This is a current requirement of the installed version of NetIQ (the access manager service for MFI).

    Edit the file /etc/ssl/openssl.cnf;
    Add the following line to the top of the file:

        openssl_conf = default_conf

    Add the following lines to the bottom of the file:

        [ default_conf ]
        ssl_conf = ssl_sect
        
        [ssl_sect]
        system_default = system_default_sect
        
        [system_default_sect]
        MinProtocol = TLSv1.2
        CipherString = DEFAULT:@SECLEVEL=1

    Save the file and test pfsso again.

