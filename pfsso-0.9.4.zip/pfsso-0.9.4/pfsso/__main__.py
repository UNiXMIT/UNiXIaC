# -*- coding: utf-8 -*-


"""pfsso.__main__: executed when pfsso directory is called as script."""


from .pfsso import main
main()