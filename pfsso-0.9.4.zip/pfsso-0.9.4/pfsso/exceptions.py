class LoginException(Exception):
    pass

