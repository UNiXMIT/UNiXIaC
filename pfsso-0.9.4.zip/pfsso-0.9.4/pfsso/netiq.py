import os
import sys
import re
import time
import base64
import requests
import itertools
import configparser
from bs4 import BeautifulSoup
from six.moves import input as raw_input
from .exceptions import *
import pkgutil

try:
    # Python 3
    from urllib.parse import urlparse, parse_qs
except ImportError:
    # Python 2
    from urlparse import urlparse, parse_qs


class auth_netiq (object):

  def __init__ (self, verbose=False, trace=False,
                tokenmode=None, tokenval=None, env="production",
                config_filename="config.ini"):

    self.saml      = None
    self.verbose   = verbose
    self.trace     = trace
    self.tokenmode = tokenmode
    self.tokenval  = tokenval
    self.session   = requests.Session()
    self.profile = "{}.{}".format(env, 'no2fa' if tokenmode is None else '2fa')

    config = configparser.ConfigParser(interpolation=None)
    data =  pkgutil.get_data('pfsso', config_filename)
    data =  data.decode('utf-8')
    config.read_string(data, config_filename)

    self.URL_LOGIN = config.get(self.profile, 'URL_LOGIN')
    self.URL_SAML = config.get(self.profile, 'URL_SAML')
    if self.trace:
      print("auth_netiq: URL_LOGIN: {}".format(self.URL_LOGIN))
      print("auth_netiq: URL_SAML: {}".format(self.URL_SAML))


  def qualify_url (self, ref_url, unqualified_url):
    if self.trace:
      print("qualify_url: unqualified_url {}".format(unqualified_url))
      print("qualify_url: ref_url {}".format(ref_url))
    a = urlparse(unqualified_url)
    o = urlparse(ref_url)
    if a.netloc:
        url = a.geturl()
    else:
        url = a._replace(scheme=o.scheme,netloc=o.netloc).geturl()
    if self.trace:
      print("qualify_url: return {}".format(url))
    return url


  def get_creds (self):
    postFields = {
      'Ecom_User_ID': self.username,
      'Ecom_Password': self.password,
      'option': 'credential',
    }
    return postFields


  def do_sms (self, url, fields):
    if self.trace:
      print("do_sms top trace: post url: {}".format(url))
      print("do_sms top fields:\n{}".format(fields))

    # seems if you have no other authenticators, netiq will preselect and
    # start SMS authorization.  If so, this code would trigger a second.
    # try to recognize the auto-start and not hit it again.
    if fields['nfst'] == 'null':
      print("==> Sending SMS 2FA initiation")
      response = self.session.post(url, data=fields)
      if self.trace:  print(response.text)
      self.soup = BeautifulSoup(response.text, "html.parser")

    #f = self.soup.find('form')
    #if f:
    #  action = f.get('action')
    #  if self.trace: print("do_sms: action: {}".format(action))
    #  action = self.qualify_url(response.url, action)

    f = self.soup.find('form')
    action = f.get('action')
    if self.trace: print("do_sms: action: {}".format(action))

    postFields = { e.get('name'): e.get('value') for e in f.find_all('input') }
    postFields["nffc"] = raw_input("SMS code: ")

    print("==> Sending SMS code")
    response = self.session.post(action, data=postFields)
    if self.trace:  print(response.text)


  def do_totp (self, url, fields):
    if self.trace:
      print("do_totp top trace: post url: {}".format(url))
      print("do_totp top fields:\n{}".format(fields))

    # seems if you have no other authenticators, netiq will preselect and
    # start SMS authorization.  If so, this code would trigger a second.
    # try to recognize the auto-start and not hit it again.
    if fields['nfst'] == 'null':
      print("==> Sending TOTP 2FA initiation")
      response = self.session.post(url, data=fields)
      if self.trace:  print(response.text)
      self.soup = BeautifulSoup(response.text, "html.parser")

    #f = self.soup.find('form')
    #if f:
    #  action = f.get('action')
    #  if self.trace: print("do_totp: action: {}".format(action))
    #  action = self.qualify_url(response.url, action)

    f = self.soup.find('form')
    action = f.get('action')
    if self.trace: print("do_totp: action: {}".format(action))

    postFields = { e.get('name'): e.get('value') for e in f.find_all('input') }

    # if token value provided programmatically, use it.  Otherwise, prompt.
    # this is only supported for TOTP mode.
    if self.tokenval:
      postFields["nffc"] = self.tokenval
    else:
      postFields["nffc"] = raw_input("TOTP Authenticator Code: ")

    print("==> Sending TOTP code")
    response = self.session.post(action, data=postFields)
    if self.trace:  print(response.text)


  def do_hotp (self, url, fields):
    if self.trace:
      print("do_hotp top trace: post url: {}".format(url))
      print("do_hotp top fields:\n{}".format(fields))

    # seems if you have no other authenticators, netiq will preselect and
    # start authorization.  If so, this code would trigger a second.
    # try to recognize the auto-start and not hit it again.
    if fields['nfst'] == 'null':
      print("==> Sending HOTP 2FA initiation")
      response = self.session.post(url, data=fields)
      if self.trace:  print(response.text)
      self.soup = BeautifulSoup(response.text, "html.parser")

    f = self.soup.find('form')
    action = f.get('action')
    if self.trace: print("do_hotp: action: {}".format(action))

    postFields = { e.get('name'): e.get('value') for e in f.find_all('input') }

    # if token value provided programmatically, use it.  Otherwise, prompt.
    # this is only supported for HOTP mode.
    if self.tokenval:
      postFields["nffc"] = self.tokenval
    else:
      postFields["nffc"] = raw_input("HOTP Authenticator Code: ")

    print("==> Sending HOTP code")
    response = self.session.post(action, data=postFields)
    if self.trace:  print(response.text)


  def do_push (self, url, fields):
    if self.trace:
      print("do_push top trace: post url: {}".format(url))
      print("do_push top fields:\n{}".format(fields))

    print("==> Sending Smartphone Push 2FA initiation")
    response = self.session.post(url, data=fields)
    if self.trace:  print(response.text)

    self.soup = BeautifulSoup(response.text, "html.parser")
    f = self.soup.find('form')
    if f:
      action = f.get('action')
      action = self.qualify_url(response.url, action)
      postFields = { e.get('name'): e.get('value') for e in f.find_all('input') }

      while (1):
        time.sleep(5)
        print("<== Awaiting redirect after Smartphone accept")
        response = self.session.post(action, data=postFields)
        if self.trace:  print(response.text)
        self.soup = BeautifulSoup(response.text, "html.parser")
        form = self.soup.find('form')
        try:
          action = form.get('action')
          action = self.qualify_url(response.url, action)
          postFields = { i['name']: i.get('value') for i in form.find_all('input') }
        except:
          break


  def do_2fa (self, url, fields):
    print("Getting list of enrolled authenticators...")

    response = self.session.post(url, data=fields)

    self.soup = BeautifulSoup(response.text, "html.parser")
    if self.trace:
      print("do_2fa trace: post url: {}".format(url))
      print("do_2fa Response body:\n{}".format(response.text))

    f = self.soup.find('form')
    if f:
      action = f.get('action')
      action = self.qualify_url(response.url, action)
      postFields = { e.get('name'): e.get('value') for e in f.find_all('input') }

    if self.trace:
      print("do_2fa: action: {}".format(action))
      print("do_2fa: fields: {}".format(postFields))

    options = {
      'SMS': { 'function': self.do_sms, 'available': False, 'nfchn': 'SMS '},
      'SMS OTP': { 'function': self.do_sms, 'available': False, 'nfchn': 'SMS OTP'},
      'SMS_OTP:1': { 'function': self.do_sms, 'available': False, 'nfchn': 'SMS OTP'},
      'TOTP': { 'function': self.do_totp, 'available': False, 'nfchn': 'TOTP'},
      'TOTP:1': { 'function': self.do_totp, 'available': False, 'nfchn': 'TOTP'},
      'Smartphone Push': { 'function': self.do_push, 'available': False, 'nfchn': 'Smartphone Push'},
      'SmartPhonePush': { 'function': self.do_push, 'available': False, 'nfchn': 'SmartPhonePush'},
      'SMARTPHONE:1': { 'function': self.do_push, 'available': False, 'nfchn': 'SmartPhonePush'},
      'HOTP': { 'function': self.do_hotp, 'available': False, 'nfchn': 'HOTP'},
      'HOTP:1': { 'function': self.do_hotp, 'available': False, 'nfchn': 'HOTP'},
    }

    try:
      for o in self.soup.find(id="naafSelect").find_all("option"):
        if o['value'].rstrip() in options:
          options[o['value'].rstrip()]['available'] = True
    except:
      nfmt = postFields['nfmt']
      if self.verbose: print("do_2fa: no naafSelect, nfmt is {}".format(nfmt))
      if nfmt in options:
        options[nfmt]['available'] = True
        self.tokenmode = nfmt
      else:
        raise LoginException("ERROR: No enrolled authenticators found for your account.")

    counter = itertools.count(1)
    menu = { str(next(counter)):v for k,v in sorted(options.items()) if v['available'] }
    selected = None

    if self.tokenmode == "ask":
      pass
    elif self.tokenmode in options and options[self.tokenmode]['available']:
      print("Pre-selecting tokenmode '{}'".format(self.tokenmode))
      selected = options[self.tokenmode]
    else:
      if self.tokenmode:
        raise LoginException("ERROR: tokenmode '{}' does not correspond to an existing authenticator - ignoring".format(self.tokenmode))
      selected = None

    while (not selected):
      print("Available MFA Authenticators")
      for k,v in sorted(menu.items()):
        print("{}. {}".format(k, v['nfchn']))

      choice = raw_input("Select authenticator number: ")
      if choice in menu:
        selected = menu[choice]
      else:
        print("Select an available option by number\n")

    nfchn = str(selected['nfchn'])
    func = selected['function']
    postFields['nfchn'] = nfchn
    func(action, postFields)


  def get_session (self, username, password, tokenval=None):
    self.username = username
    self.password = password
    self.tokenval = tokenval
    if self.trace: print("get_session: trace")

    response = self.session.post(self.URL_LOGIN, data=self.get_creds())
    if self.trace:
      print("get_session: response code: {}".format(response))
      print("get_session: response body:\n{}".format(response.text))

    self.soup = BeautifulSoup(response.text, "html.parser")
    f = self.soup.find('form')
    if f:
      action = f.get('action')
      action = self.qualify_url(response.url, action)
      if self.trace: print("do_login: form action: {}".format(action))
      postFields = { e.get('name'): e.get('value') for e in f.find_all('input') }

      if 'Ecom_Password' in postFields:
        raise LoginException("Bad username or password")

      if re.search('/auth/oauth2/grant', action):
        self.do_2fa(action, postFields)


  def get_saml_base64 (self):
    if self.trace:
      print("get_saml_base64: url: {}".format(self.URL_SAML))
      print("get_saml_base64: cookies: {}".format(self.session.cookies))

    response = self.session.post(self.URL_SAML, cookies=self.session.cookies)
    if self.trace:
      print("get_saml_base64: response code: {}".format(response))
      print("get_saml_base64: response body:\n{}".format(response.text))

    self.soup = BeautifulSoup(response.text, "html.parser")

    for inputtag in self.soup.find_all('input'):
      if inputtag.get('name') == 'SAMLResponse':
        assertion = inputtag.get('value')
        self.saml = assertion

    return self.saml

  def get_saml (self):
    return base64.b64decode(get_saml_base64())

