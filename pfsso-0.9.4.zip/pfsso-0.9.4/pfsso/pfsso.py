"""
pfsso - AWS authentication from PingFederate and NetIQ
"""

from __future__ import print_function
from bs4 import BeautifulSoup
from collections import namedtuple

from datetime import datetime,timedelta

import requests
import re
import xml.etree.ElementTree as ET
import base64
from tabulate import tabulate
import sys, os, argparse, getpass
import time
import pkg_resources
from .exceptions import *
from .netiq import auth_netiq
import traceback


import boto3

# Try Python 3
try:
   input = raw_input
except NameError:
   pass

# Try Python 3
try:
    from urllib.parse import urlparse
# Fall back to Python 2
except ImportError:
     from urlparse import urlparse

# Try Python 3
try:
    from configparser import ConfigParser,RawConfigParser
# Fall back to Python 2
except:
    from ConfigParser import ConfigParser,RawConfigParser

class pfsso(object):

    def __init__(self, username, password, tokenmode=None, tokenval=None,
                 url='https://login.ext.hpe.com/idp/startSSO.ping?PartnerSpId=urn:amazon:webservices',
                 verbose=False, trace=False
    ):
        # Initialize variables
        self.username = username
        self.password = password
        self.tokenmode = tokenmode
        self.tokenval = tokenval
        self.url = url
        self.verbose = verbose
        self.trace = trace
        self.roles = {}
        self.role_tuple = namedtuple("role_tuple", ["name", "parn", "rarn"])

        # Do stuff
        if re.match('.+@hpe.com', self.username):
            self.idp = "HPE_IdP"
            self.hpe_sso()
        elif re.match('.+@microfocus.com', self.username):
            self.idp = "MF_IDP"
            self.mf_sso()
        else:
           raise

        # only try to add roles if we get an assertion back
        if self.samlassertion:
            if self.trace: print("SAML: {}".format(self.samlassertion))
            self.build_roles()

    def parse_form_inputs(self,response):
        soup = BeautifulSoup(response.text, "html.parser")
        postFields = {}
        for ip in soup.find_all('input'):
            if ip.get('name') and ip.get('name')[:2] == 'pf':
                postFields['pf.ok'] = 'clicked'
                postFields['pf.cancel'] = ''
                postFields['pf.username'] = self.username
                postFields['pf.pass'] = self.password

            postFields['submit'] = 'Resume'
            postFields[ip.get('name')] = ip.get('value')
        return postFields

    def hpe_sso(self):
        sslverification=True
        postFields = {'contextResult': 'No'}
        if self.verbose:
            print("Beginning authentication with HPE SSO for user %s" % self.username)

        S = requests.Session()
        action = self.url

        count = 0
        while action and action != "https://signin.aws.amazon.com/saml" and count <= 8:
            if self.trace:
                print("")
                print("    posting: %s" % action)
            response = S.post(action, data=postFields, verify=sslverification)
            action = self.get_action_url(response)
            if not action:
                action = response.url
            postFields = self.parse_form_inputs(response)
            count = count + 1
            if count == 8:
                print("Incorrect password")
                return None

        # read the HTML response, parse the result
        assertion = None
        soup = BeautifulSoup(response.text, "html.parser")

        for inputtag in soup.find_all('input'):
            if inputtag.get('name') == 'SAMLResponse':
                assertion = inputtag.get('value')

        if not assertion:
            print("ERROR: Invalid assertion: %s " % assertion)

        # return the saml assertion
        self.samlassertion = assertion

        if self.verbose:
            print("Completed auth with HPE SSO")
            print("")

    def mf_sso(self):
        if self.verbose:
            print("Beginning authentication with MF SSO for user %s" % self.username)
        env = os.environ.get('PFSSO_NAM_ENV', 'production')
        s = auth_netiq(env=env, tokenmode=self.tokenmode,
                       verbose=self.verbose, trace=self.trace)
        try:
            s.get_session( self.username, self.password, self.tokenval )
            self.samlassertion = s.get_saml_base64()
        except Exception as e:
            self.samlassertion = None
            print(str(e))
            if self.verbose:
                traceback.print_exc()

        if self.verbose:
            if self.samlassertion is not None:
                print("Completed auth with MF SSO")
            else:
                print("FAILED auth with MF SSO")
            print("")

    # Find the action URL from the session data
    def get_action_url(self, session):
        formsoup = BeautifulSoup(session.text,'html.parser')
        action = None

        if self.trace:
            print("session.url: %s" % session.url)
            print("----BEGIN DATA ----------")
            print(formsoup)
            print("--- END DATA ------------")
            print("")

        for inputtag in formsoup.find_all(re.compile('(FORM|form)')):
            action = inputtag.get('action')
            break

        if not action:
            return None

        if self.trace:
            print("     action: %s" % action)

        if action[-1:] == "/":
            action += "startSSO.ping"

        if action[:5] != "https":
            #action = "https://login-iam.ext.hpe.com" + action
            #action = "https://login.ext.hpe.com" + action
            url = urlparse(session.url)
            action = "%s://%s%s" % (url.scheme, url.netloc, action)

        return action

    # Build the list of roles I have, based on my SAML assertion
    def build_roles(self):
        root = ET.fromstring(base64.b64decode(self.samlassertion))

        # Debug
        # print(base64.b64decode(self.samlassertion))

        for saml2attribute in root.iter('{urn:oasis:names:tc:SAML:2.0:assertion}Attribute'):
            if saml2attribute.get('Name') == 'https://aws.amazon.com/SAML/Attributes/Role':
                for saml2attributevalue in saml2attribute.iter('{urn:oasis:names:tc:SAML:2.0:assertion}AttributeValue'):
                    for arn in saml2attributevalue.text.split(','):
                        if re.search(":saml-provider/", arn):
                           parn = arn
                        else:
                           rarn = arn
                    #print("parn:", parn)
                    #print("rarn:", rarn)
                    acct = pfsso.get_acct(rarn)
                    role = pfsso.get_role(rarn)

                    role_tuple = self.role_tuple(role, parn, rarn)
                    if acct in self.roles:
                        self.roles[acct].append(role_tuple)
                    else:
                        self.roles[acct] = [ role_tuple ]

    # Parse the Account ID from the role_arn
    @staticmethod
    def get_acct(role_arn):
        return role_arn.split(':')[4]

    # Parse the Role name from the role_arn
    @staticmethod
    def get_role(role_arn):
        return role_arn.split('/')[1]


    # -------------------------------------------------------------------------------------------------
    # DO AWS STUFF
    @staticmethod
    def get_sts_token(account_id, role_session_name = "MasterBilling"):
        try:
            session = boto3.Session(profile_name='MasterBilling')
            sts = session.client('sts')
            response_data = sts.assume_role(
                            RoleArn="arn:aws:iam::%s:role/Cloud-Governance-Parent-Account-Access-Role" % account_id,
                            RoleSessionName=role_session_name)
        except Exception as e:
            print("ERROR getting token from account %s." % account_id)
            print(e)
            return None

        return response_data

    def get_sts_token_saml(self, role_arn, principal_arn,
                           assertion, duration=3600
    ):
        if self.verbose:
            print("role_arn:", role_arn)
            print("principal_arn:", principal_arn)
            #print("assertion:", assertion)
        try:
            sts = boto3.client('sts')
            response_data = sts.assume_role_with_saml(RoleArn=role_arn, PrincipalArn=principal_arn, SAMLAssertion=assertion, DurationSeconds=duration)
        except Exception as e:
            print('ERROR getting token from SAML Assertion.')
            print(e)
            return None

        return response_data

    @staticmethod
    def get_sts_token_creds(account_id, token, aws_region, role_session_name = "MasterBilling", role_name="Cloud-Governance-Parent-Account-Access-Role"):
        try:
            sts = pfsso.get_client_creds('sts',token,aws_region)
            if sts == None:
                print("Error... get_client_creds sts is None")
            response_data = sts.assume_role(
                RoleArn="arn:aws:iam::%s:role/%s" % (account_id, role_name),
                RoleSessionName=role_session_name)
        except Exception as e:
            print("ERROR getting token from account %s." % account_id)
            print(e)
            return None

        return response_data

    @staticmethod
    def get_client_creds(aws_service,creds,aws_region,config=None):
        return boto3.client(
            aws_service,
            aws_access_key_id=creds['Credentials']['AccessKeyId'],
            aws_secret_access_key=creds['Credentials']['SecretAccessKey'],
            aws_session_token=creds['Credentials']['SessionToken'],
            region_name=aws_region,
            config=config
        )

    # -------------------------------------------------------------------------------------------------
    # DO FILE STUFF

    # Write the token credentials to the credential file
    @staticmethod
    def write_aws_credentials(section, token, region, outputformat, creds_file):
        #if self.verbose:
        #    print("Writing creds: %s" % section)

        if not token:
            print("ERROR: Invalid token. Check your credentials.")
            return None

        # Ensure ~/.aws directory exists
        config_dir = os.path.expanduser("~") + '/.aws'
        if not os.path.isdir(config_dir):
            os.mkdir(config_dir)

        config = RawConfigParser()
        config.read(creds_file)

        # if the section doesn't exist, add it
        if not config.has_section(section):
            config.add_section(section)

        if token and 'Credentials' in token:
            access_key = token['Credentials']['AccessKeyId']
            secret_key = token['Credentials']['SecretAccessKey']
            session_token = token['Credentials']['SessionToken']
        elif token and 'AssumedRoleUser' in token:
            access_key = token['AssumedRoleUser']['AccessKeyId']
            secret_key = token['AssumedRoleUser']['SecretAccessKey']
            session_token = token['AssumedRoleUser']['SessionToken']

        # update the section with the new information
        config.set(section, 'output', outputformat)
        config.set(section, 'region', region)
        config.set(section, 'aws_access_key_id', access_key)
        config.set(section, 'aws_secret_access_key', secret_key)
        config.set(section, 'aws_session_token', session_token)
        config.set(section, 'aws_security_token', session_token)

        # write out the new config file to disk
        with open(creds_file, 'w+') as configfile:
            config.write(configfile)

# --------------------------------------------------------------------------

# find first environment variable set in list and return value
def get_envvar (varnames):
    for v in varnames:
        if v in os.environ:
            return os.environ.get(v)
    return None

def parse_args(arguments):
    parser = argparse.ArgumentParser(description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter)

    parser.add_argument('-a', '--all-roles',
        help="Refresh credentials for all roles",
        action='store_true',
        default=False,
    )
    parser.add_argument('-r', '--accounts',
        help='List of AWS Account IDs to refresh',
        nargs='+',
        default=None,
    )
    parser.add_argument('-c', '--creds-file',
        help="AWS Credentials file (default ~/.aws/credentials)",
        default=os.path.expanduser("~")+'/.aws/credentials',
    )
    parser.add_argument('-n', '--config',
        help="Set profile aliases (default ~/.aws/pfsso_config)",
        default=os.path.expanduser("~")+'/.aws/pfsso_config',
    )
    parser.add_argument('-o', '--output',
        help="AWS output format (default json)",
        default='json',
    )
    parser.add_argument('-s', '--hours',
        help="Session duration (hours)",
        type=int,
        choices=range(1,12+1),
        default=1,
    )
    parser.add_argument('-2', '--tokenmode',
        help="Authenticator for 2-factor.  Use 'ask' for choices. ",
        #choices=['SMS', 'TOTP', 'HOTP', 'Smartphone Push'],
        default=os.environ.get('PFSSO_TOKENMODE'),
    )
    parser.add_argument('-m', '--mgmt-acct-id',
        help="Management Account ID",
    )
    parser.add_argument('-l', '--roles',
        help="Display AWS roles only",
        dest='roles',
        action='store_true',
    )
    parser.add_argument('-u', '--username',
        help="SSO Username",
        default=get_envvar(['PFSSO_USERNAME','HPE_USERNAME']),
    )
    parser.add_argument('-p', '--password',
        help=argparse.SUPPRESS,
        default=get_envvar(['PFSSO_PASSWORD','HPE_PASSWORD']),
    )
    parser.add_argument('-g', '--region',
        help="AWS Region (default ENV ${AWS_REGION}",
        default=os.environ.get('AWS_REGION'),
    )
    parser.add_argument('-v', '--verbose',
        dest='verbose',
        action='store_true',
        help="Print verbose debugging messages",
        default=False,
    )
    parser.add_argument('-t', '--trace',
        dest='trace',
        action='store_true',
        help="Print more verbose debugging messages",
        default=False,
    )
    parser.add_argument('--version', dest='version',
        action='store_true',
        help="Print version and exit",
        default=False,
    )

    args = parser.parse_args(arguments)

    if args.version:
        print(pkg_resources.get_distribution('pfsso').version)
        exit()

    # If they didn't specify any accounts, then fail and print the help message
    if args.all_roles is False and args.accounts is None:
        print("ERROR: Must specify account IDs to refresh with -r or refresh all account IDs with -a.")
        print("")
        parser.print_help()
        exit()

    if args.username is None:
        args.username = input("SSO Email: ")

    if args.password is None:
        args.password = getpass.getpass("SSO Password: ")

    if args.region is None:
        args.region = 'us-west-2'

    if not isinstance(args.hours, int):
        args.hours = int(args.hours)

    if args.hours > 12:
        args.hours = 12

    if args.hours < 1:
        args.hours = 1

    return args

# -------------------------------------------------------------------------------------------------

def build_pfsso_config_parser(config_file):
    config = ConfigParser()
    config.read(config_file)
    config_dict = {}
    for section in config.sections():
        options = config.options(section)
        for option in options:

            if section in config_dict:
                config_dict[section][option] = config.get(section, option)
            else:
                config_dict[section] = { option: config.get(section, option) }
    return config_dict

# -------------------------------------------------------------------------------------------------


def main():

    args = parse_args(sys.argv[1:])

    config_dict = build_pfsso_config_parser(args.config)

    # Convert hours args to seconds for AWS API call
    duration = args.hours * 60 * 60

    # print("Hours Remaining: %s" % hours_remaining)

    # Go login to Corp SSO and populate with SAML Assertion and my roles
    hpe_user = pfsso(args.username, args.password, tokenmode=args.tokenmode, verbose=args.verbose, trace=args.trace)

    if not hpe_user.samlassertion:
        print("Error logging you in to IT Corp AD.")
        print("    Please verify your credentials by logging in manually")
        print("")
        exit(1)

    # Only print out my list of roles
    if args.roles:
        print("Printing AWS roles only:")
        r = { acct:[r.name for r in x] for acct,x in hpe_user.roles.items() }
        print(tabulate(r.items()))
        exit(0)

    # If all roles, then loop through roles/accounts
    for accid,roles in hpe_user.roles.items():
        if args.all_roles or accid in args.accounts:
            print("")

            if args.trace:
                print ("%s %s" % (accid,roles) )

            # Add roles as <accid_rolen>
            for role in roles:
                parn = role.parn
                rarn = role.rarn
                rname = role.name

                creds = hpe_user.get_sts_token_saml(rarn, parn, hpe_user.samlassertion, duration)
                if creds:
                    hpe_user.write_aws_credentials(
                        "%s_%s" % (accid, rname),
                        creds,
                        args.region,
                        args.output,
                        args.creds_file
                    )
                    print ("Added %s_%s" % (accid, rname))
                else:
                    print ("Skipping %s_%s" % (accid, rname))


            # If the user has multiple roles,
            # and Fed_Account_Admin is in there, add it as default
            rname = role.name
            if rname in ['HPE_Account_Admin', 'Fed_Account_Admin']:
                parn = role.parn
                rarn = role.rarn

                creds = hpe_user.get_sts_token_saml(rarn, parn, hpe_user.samlassertion, duration)
                if creds:            
                    hpe_user.write_aws_credentials(
                        accid,
                        creds,
                        args.region,
                        args.output,
                        args.creds_file
                    )
                    print ("Added %s (%s)" % (accid,rname))
                else:
                    print ("Skipping %s (%s)" % (accid,rname))

            # Check the config file and add any role aliases
            if accid in config_dict:
                role_name = config_dict[accid]['aws_role_name']
                profile_name = config_dict[accid]['aws_profile_name']
                rarn = "arn:aws:iam::%s:role/%s" % (accid,role_name)

                creds = hpe_user.get_sts_token_saml(rarn, parn, hpe_user.samlassertion, duration)
                if creds:              
                    hpe_user.write_aws_credentials(
                        profile_name,
                        creds,
                        args.region,
                        args.output,
                        args.creds_file
                    )
                    print ("Added %s" % profile_name)

                else:
                    print("Skipping %s" % profile_name)

        # Use MBA, create children
        for section in config_dict:
            if 'mba_assume_role' in section:
                print("")
                profile_name = config_dict[section]['aws_profile_name']
                accid = config_dict[section]['aws_account_id']

                creds = hpe_user.get_sts_token(accid)
                if creds:
                    hpe_user.write_aws_credentials(
                        profile_name,
                        creds,
                        args.region,
                        args.output,
                        args.creds_file
                    )
                    print("Added %s (%s from MBA)" % (profile_name,accid))

                else:
                    print("Skipping %s" % 'HPE_Account_Admin')

    expires = datetime.now() + timedelta(seconds=duration)
    print("")
    print("AWS Credentials will be valid until: %s" % expires.strftime('%c'))
