#!/bin/bash
ansible-playbook rhel9.yml -i inventory
